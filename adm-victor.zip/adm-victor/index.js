const qrcode = require("qrcode-terminal");
const moment = require("moment");
const cheerio = require("cheerio");
const get = require('got')
const fs = require("fs");
const dl = require("./lib/downloadImage.js");
const fetch = require('node-fetch');
const urlencode = require("urlencode");
const axios = require("axios");
const imageToBase64 = require('image-to-base64');
const menu = require("./lib/menu.js");
const donate = require("./lib/donate.js");
const info = require("./lib/info.js");
//
const BotName = 'BOT ADM VICTOR'; // Nama Bot Whatsapp
const instagramlu = 'https://www.instagram.com/gamerlagado/'; // Nama Instagramlu cok
const whatsapplu = '0895-2325-8649'; // Nomor whatsapplu cok
const kapanbotaktif = '24 hora'; // Kapan bot lu aktif
const grupch1 = 'https://chat.whatsapp.com/Eedio1m9BcO6YpY8vDE2p7'; // OFFICIAL GRUP LU 1
//
const
{
   WAConnection,
   MessageType,
   Presence,
   MessageOptions,
   Mimetype,
   WALocationMessage,
   WA_MESSAGE_STUB_TYPES,
   ReconnectMode,
   ProxyAgent,
   waChatKey,
} = require("@adiwajshing/baileys");
var hora = moment().format("HH:mm");

function foreach(arr, func)
{
   for (var i in arr)
   {
      func(i, arr[i]);
   }
}
const conn = new WAConnection()
conn.on('qr', qr =>
{
   qrcode.generate(qr,
   {
      small: true
   });
   console.log(`[ ${moment().format("HH:mm:ss")} ] Scan kode qr mu cok!`);
});

conn.on('credentials-updated', () =>
{
   // save credentials whenever updated
   console.log(`credentials updated!`)
   const authInfo = conn.base64EncodedAuthInfo() // get all the auth info we need to restore this session
   fs.writeFileSync('./session.json', JSON.stringify(authInfo, null, '\t')) // save this info to a file
})
fs.existsSync('./session.json') && conn.loadAuthInfo('./session.json')
// uncomment the following line to proxy the connection; some random proxy I got off of: https://proxyscrape.com/free-proxy-list
//conn.connectOptions.agent = ProxyAgent ('http://1.0.180.120:8080')
conn.connect();

conn.on('user-presence-update', json => console.log(`[ ${moment().format("HH:mm:ss")} ] => bot by VICTOR`))
conn.on('message-status-update', json =>
{
   const participant = json.participant ? ' (' + json.participant + ')' : '' // participant exists when the message is from a group
   console.log(`[ ${moment().format("HH:mm:ss")} ] => bot by VICTOR`)
})

conn.on('message-new', async(m) =>
{
   const messageContent = m.message
   const text = m.message.conversation
   let id = m.key.remoteJid
   const messageType = Object.keys(messageContent)[0] // message will always contain one key signifying what kind of message
   let imageMessage = m.message.imageMessage;
   console.log(`[ ${moment().format("HH:mm:ss")} ] => Nomor: [ ${id.split("@s.whatsapp.net")[0]} ] => ${text}`);


// Groups

if (text.includes("#buatgrup"))
   {
var nama = text.split("#buatgrup")[1].split("-nomor")[0];
var nom = text.split("-nomor")[1];
var numArray = nom.split(",");
for ( var i = 0; i < numArray.length; i++ ) {
    numArray[i] = numArray[i] +"@s.whatsapp.net";
}
var str = numArray.join("");
console.log(str)
const group = await conn.groupCreate (nama, str)
console.log ("created group with id: " + group.gid)
conn.sendMessage(group.gid, "Salve galera", MessageType.extendedText) // say hello to everyone on the group

}

// FF
if(text.includes("#cek")){
var num = text.replace(/#cek/ , "")
var idn = num.replace("0","+55");

console.log(id);
const gg = idn+'@s.whatsapp.net'

const exists = await conn.isOnWhatsApp (gg)
console.log(exists);
conn.sendMessage(id ,`${gg} ${exists ? " existe " : " Não existe"} no WhatsApp`, MessageType.text)
}

if (text.includes("#say")){
  const teks = text.replace(/#say /, "")
conn.sendMessage(id, teks, MessageType.text)
}

if (text.includes("#nulis")){
  const teks = text.replace(/#nulis /, "")
axios.get(`https://mhankbarbar.herokuapp.com/nulis?text=${teks}&apiKey=zFuV88pxcIiCWuYlwg57`).then((res) => {
    let hasil = `Baixe você mesmo os resultados abaixo, porque se você enviá-los, os resultados ficam borrados\n\n${res.data.result}`;
    conn.sendMessage(id, hasil ,MessageType.text);
})
}

if (text.includes("#ytmp3")){
const teks = text.replace(/#ytmp3 /, "")
axios.get(`https://mhankbarbar.herokuapp.com/api/yta?url=${teks}&apiKey=zFuV88pxcIiCWuYlwg57`).then((res) => {
    let hasil = `Baixe você mesmo através do link abaixo, infelizmente o servidor está fora do ar..\n\nSize: ${res.data.filesize}\n\nLink: ${res.data.result}`;
    conn.sendMessage(id, hasil ,MessageType.text);
})
}

if (text.includes("#yt")){
const teks = text.replace(/#yt /, "")
axios.get(`https://mhankbarbar.herokuapp.com/api/ytv?url=${teks}&apiKey=zFuV88pxcIiCWuYlwg57`).then((res) => {
    let hasil = `Baixe você mesmo através do link abaixo, infelizmente o servidor está fora do ar..\n\nSize: ${res.data.filesize}\n\nLink: ${res.data.result}`;
    conn.sendMessage(id, hasil ,MessageType.text);
})
}

if (text.includes("#fb")){
const teks = text.replace(/#fb /, "")
axios.get(`https://mhankbarbar.herokuapp.com/api/epbe?url=${teks}&apiKey=zFuV88pxcIiCWuYlwg57`).then((res) => {
    let hasil = `Baixe você mesmo através do link abaixo, infelizmente o servidor está fora do ar..\n\nJudul: ${res.data.title}\n\nSize: ${res.data.filesize}\n\nLink: ${res.data.result}`;
    conn.sendMessage(id, hasil ,MessageType.text);
})
}

if (text.includes("#ig")){
const teks = text.replace(/#ig /, "")
axios.get(`https://mhankbarbar.herokuapp.com/api/ig?url=${teks}&apiKey=zFuV88pxcIiCWuYlwg57`).then((res) => {
    let hasil = `Baixe você mesmo através do link abaixo, infelizmente o servidor está fora do ar..\n\nLink: ${res.data.result}`;
    conn.sendMessage(id, hasil ,MessageType.text);
})
}

if (text.includes("#twt")){
const teks = text.replace(/#twt /, "")
axios.get(`https://mhankbarbar.herokuapp.com/api/twit?url=${teks}&apiKey=zFuV88pxcIiCWuYlwg57`).then((res) => {
    let hasil = `Baixe você mesmo através do link abaixo, infelizmente o servidor está fora do ar..\n\nJudul: ${res.data.title}\n\nSize: ${res.data.filesize}\n\nLink: ${res.data.result}`;
    conn.sendMessage(id, hasil ,MessageType.text);
})
}

if (text.includes("#wiki")){
const teks = text.replace(/#wiki /, "")
axios.get(`https://mhankbarbar.herokuapp.com/api/wiki?q=${teks}&lang=id&apiKey=zFuV88pxcIiCWuYlwg57`).then((res) => {
    let hasil = `De acordo com a Wikipedia:\n\n${res.data.result}`;
    conn.sendMessage(id, hasil ,MessageType.text);
})
}

if (text == '#help'){
const corohelp = await get.get('').json()
var data = new Date();
var ano = date.getFullYear();
var mes = date.getMonth();
var encontro = date.getDate();
var dia = date.getDay();
var hora = date.getHours();
var minuto = date.getMinutes();
var segundo = date.getSeconds();
switch(dia) {
 case 0: dia = "Domingo"; break;
 case 1: dia = "Segunda-feira"; break;
 case 2: dia = "Terca-feira"; break;
 case 3: dia = "Quarta-Feira"; break;
 case 4: dia = "Quinta-Feira"; break;
 case 5: dia = "Sexta-Feira"; break;
 case 6: dia = "Sabado"; break;
}
switch(mes) {
 case 0: mes = "Janeiro"; break;
 case 1: mes = "Fevereiro"; break;
 case 2: mes = "Marco"; break;
 case 3: mes = "Abril"; break;
 case 4: mes = "Maio"; break;
 case 5: mes = "Junho"; break;
 case 6: mes = "Julho"; break;
 case 7: mes = "Agosto"; break;
 case 8: mes = "Setembro"; break;
 case 9: mes = "Outubro"; break;
 case 10: mes = "Novembro"; break;
 case 11: mes = "Dezembro"; break;
}
var tampilTanggal = "DATA: " + dia + ", " + data + " " + mes + " " + ano;
var tampilWaktu = "HORA: " + hora + ":" + minuto + ":" + segundo;
conn.sendMessage(id, menu.menu(id, BotName, corohelp, tampilTanggal, tampilWaktu, instagramlu, whatsapplu, kapanbotaktif, grupch1, grupch2) ,MessageType.text);
}
else if (text == '#quran'){
axios.get('https://api.banghasan.com/quran/format/json/acak').then((res) => {
    const sr = /{(.*?)}/gi;
    const hs = res.data.acak.id.ayat;
    const ket = `${hs}`.replace(sr, '');
    let hasil = `[${ket}]   ${res.data.acak.ar.teks}\n\n${res.data.acak.id.teks}(QS.${res.data.surat.nama}, Ayat ${ket})`;
    conn.sendMessage(id, hasil ,MessageType.text);
})
}
else if (text == 'Bom Dia'){
conn.sendMessage(id, 'Bom dia, Precisa de algo ? digite #help e veja' ,MessageType.text);
}
else if (text == 'Boa Tarde'){
conn.sendMessage(id, 'Boa Tarde, Precisa de algo ? digite #help e veja' ,MessageType.text);
}
else if (text == 'Boa Noite'){
conn.sendMessage(id, 'Boa Noite, Precisa de algo ? digite #help e veja' ,MessageType.text);
}
else if (text == 'Oi'){
conn.sendMessage(id, 'Olá, Precisa de algo ? digite #help e veja' ,MessageType.text);
}
else if (text == 'Salve'){
conn.sendMessage(id, 'Salve, Precisa de algo ? digite #help e veja' ,MessageType.text);
}
else if (text == 'Eae'){
conn.sendMessage(id, 'Eae, beleza ? Precisa de algo ? digite #help e veja' ,MessageType.text);
}
else if (text == 'Feminista'){
conn.sendMessage(id, 'Vai se depilar feminista gorda' ,MessageType.text);
}
else if (text == 'Traveco'){
conn.sendMessage(id, 'Rodizio de Traveco, 5 conto' ,MessageType.text);
}
else if (text == 'LGTV'){
conn.sendMessage(id, 'Nao seja LGTV, procure tratamento' ,MessageType.text);
}
else if (text == 'Cogu'){
conn.sendMessage(id, 'Cogu ADM gordao, vai tetudo' ,MessageType.text);
}
else if (text == 'Shadowkan'){
conn.sendMessage(id, 'SHADOWKAN ADM SUPREMO' ,MessageType.text);
}
else if (text == 'VICTOR'){
conn.sendMessage(id, 'ADM Victor, meu criador e Deus desse bot, meninas fazem plaquinha pra ele' ,MessageType.text);
}
else if (text == 'Miranha'){
conn.sendMessage(id, 'ADM Miranha nao tem 14 anos, tem 28' ,MessageType.text);
}
else if (text == 'Coyote'){
conn.sendMessage(id, 'Coyote ADM Pedofilo, teta preta' ,MessageType.text);
}
else if (text == 'Vitu'){
conn.sendMessage(id, ' Vitu ADM Sombrio, todo esquizofrenico e gado' ,MessageType.text);
}
else if (text == 'Joao'){
conn.sendMessage(id, 'Joao ADM Macaco, o mais pedofilo do grupo' ,MessageType.text);
}
else if (text == 'Uchizzaki'){
conn.sendMessage(id, 'Uchizzaki que se foda' ,MessageType.text);
}
else if (text == 'Martins'){
conn.sendMessage(id, 'Martins da o cu para o grupo.' ,MessageType.text);
}
else if (text == 'Nayara'){
conn.sendMessage(id, 'Nayara é traveco' ,MessageType.text);
}
else if (text == 'Andre'){
conn.sendMessage(id, 'andre, todo saopaulino é viado' ,MessageType.text);
}
else if (text == 'Abner'){
conn.sendMessage(id, 'Abner cabelo de anime e diferente de mendigo' ,MessageType.text);
}
else if (text == 'Victoria'){
conn.sendMessage(id, 'Victoria a mina que faz plaquinha' ,MessageType.text);
}
else if (text == '#donate'){
const corohelp = await get.get('').json()
var data = new Date();
var ano = date.getFullYear();
var mes = date.getMonth();
var encontro = date.getDate();
var dia = date.getDay();
var hora = date.getHours();
var minuto = date.getMinutes();
var segundo = date.getSeconds();
switch(dia) {
 case 0: dia = "Domingo"; break;
 case 1: dia = "Segunda-feira"; break;
 case 2: dia = "Terca-feira"; break;
 case 3: dia = "Quarta-Feira"; break;
 case 4: dia = "Quinta-Feira"; break;
 case 5: dia = "Sexta-Feira"; break;
 case 6: dia = "Sabado"; break;
}
switch(mes) {
 case 0: mes = "Janeiro"; break;
 case 1: mes = "Fevereiro"; break;
 case 2: mes = "Marco"; break;
 case 3: mes = "Abril"; break;
 case 4: mes = "Maio"; break;
 case 5: mes = "Junho"; break;
 case 6: mes = "Julho"; break;
 case 7: mes = "Agosto"; break;
 case 8: mes = "Setembro"; break;
 case 9: mes = "Outubro"; break;
 case 10: mes = "Novembro"; break;
 case 11: mes = "Dezembro"; break;
}
var tampilTanggal = "Encontro: " + dia + ", " + encontro + " " + mes + " " + ano;
var tampilWaktu = "hora: " + hora + ":" + minuto + ":" + segundo;
conn.sendMessage(id, donate.donate(id, BotName, corohelp, tampilTanggal, tampilWaktu, instagramlu, whatsapplu, kapanbotaktif, grupch1, grupch2) ,MessageType.text);
}
else if (text == '#doacao'){
const corohelp = await get.get('').json()
var data = new Date();
var ano = date.getFullYear();
var mes = date.getMonth();
var encontro = date.getDate();
var dia = date.getDay();
var hora = date.getHours();
var minuto = date.getMinutes();
var segundo = date.getSeconds();
switch(dia) {
 case 0: dia = "Domingo"; break;
 case 1: dia = "Segunda-feira"; break;
 case 2: dia = "Terca-feira"; break;
 case 3: dia = "Quarta-Feira"; break;
 case 4: dia = "Quinta-Feira"; break;
 case 5: dia = "Sexta-Feira"; break;
 case 6: dia = "Sabado"; break;
}
switch(mes) {
 case 0: mes = "Janeiro"; break;
 case 1: mes = "Fevereiro"; break;
 case 2: mes = "Marco"; break;
 case 3: mes = "Abril"; break;
 case 4: mes = "Maio"; break;
 case 5: mes = "Junho"; break;
 case 6: mes = "Julho"; break;
 case 7: mes = "Agosto"; break;
 case 8: mes = "Setembro"; break;
 case 9: mes = "Outubro"; break;
 case 10: mes = "Novembro"; break;
 case 11: mes = "Dezembro"; break;
}
var tampilTanggal = "ENCONTRO: " + dia + ", " + encontro + " " + mes + " " + ano;
var tampilWaktu = "hora: " + hora + ":" + minuto + ":" + segundo;
conn.sendMessage(id, donate.donate(id, BotName, corohelp, tampilTanggal, tampilWaktu, instagramlu, whatsapplu, kapanbotaktif, grupch1, grupch2) ,MessageType.text);
}
else if (text == '#DONATE'){
const corohelp = await get.get('').json()
var data = new Date();
var ano = date.getFullYear();
var mes = date.getMonth();
var encontro = date.getDate();
var dia = date.getDay();
var hora = date.getHours();
var minuto = date.getMinutes();
var segundo = date.getSeconds();
switch(dia) {
 case 0: dia = "Domingo"; break;
 case 1: dia = "Segunda-Feira"; break;
 case 2: dia = "Terca-feira"; break;
 case 3: dia = "Quarta-feira"; break;
 case 4: dia = "Quinta-feira"; break;
 case 5: dia = "Sexta-Feira"; break;
 case 6: dia = "Sabado"; break;
}
switch(mes) {
 case 0: mes = "Janeiro"; break;
 case 1: mes = "Fevereiro"; break;
 case 2: mes = "Marco"; break;
 case 3: mes = "Abril"; break;
 case 4: mes = "Maio"; break;
 case 5: mes = "Junho"; break;
 case 6: mes = "Julho"; break;
 case 7: mes = "Agosto"; break;
 case 8: mes = "Setembro"; break;
 case 9: mes = "Outubro"; break;
 case 10: mes = "Novembro"; break;
 case 11: mes = "Dezembro"; break;
}
var tampilTanggal = "ENCONTRO: " + dia + ", " + encontro + " " + mes + " " + ano;
var tampilWaktu = "HORA: " + hora + ":" + minuto + ":" + segundo;
conn.sendMessage(id, donate.donate(id, BotName, corohelp, tampilTanggal, tampilWaktu, instagramlu, whatsapplu, kapanbotaktif, grupch1, grupch2) ,MessageType.text);
}
else if (text == '#DONASI'){
  const corohelp = await get.get('').json()
var date = new Date();
var ano = date.getFullYear();
var mes = date.getMonth();
var encontro = date.getDate();
var dia = date.getDay();
var hora = date.getHours();
var minuto = date.getMinutes();
var segundo = date.getSeconds();
switch(dia) {
 case 0: dia = "Domingo"; break;
 case 1: dia = "Segunda-feira"; break;
 case 2: dia = "Terca-feira"; break;
 case 3: dia = "Quarta-feira"; break;
 case 4: dia = "Quinta-feira"; break;
 case 5: dia = "Sexta-Feira"; break;
 case 6: dia = "Sabado"; break;
}
switch(mes) {
 case 0: mes = "Janeiro"; break;
 case 1: mes = "Fevereiro"; break;
 case 2: mes = "Marco"; break;
 case 3: mes = "Abril"; break;
 case 4: mes = "Maio"; break;
 case 5: mes = "Junho"; break;
 case 6: mes = "Julho"; break;
 case 7: mes = "Agosto"; break;
 case 8: mes = "Setembro"; break;
 case 9: mes = "Outubro"; break;
 case 10: mes = "Novembro"; break;
 case 11: mes = "Dezembro"; break;
}
var tampilTanggal = "ENCONTRO: " + dia + ", " + encontro + " " + mes + " " + ano;
var tampilWaktu = "hora: " + hora + ":" + minuto + ":" + segundo;
conn.sendMessage(id, donate.donate(id, BotName, corohelp, tampilTanggal, tampilWaktu, instagramlu, whatsapplu, kapanbotaktif, grupch1, grupch2) ,MessageType.text);
}
else if (text == '#info'){
  const corohelp = await get.get('').json()
var data = new Date();
var ano = date.getFullYear();
var mes = date.getMonth();
var encontro = date.getDate();
var dia = date.getDay();
var hora = date.getHours();
var minuto = date.getMinutes();
var segundo = date.getSeconds();
switch(dia) {
 case 0: dia = "Domingo"; break;
 case 1: dia = "Segunda-Feira"; break;
 case 2: dia = "Quarta-feira"; break;
 case 3: dia = "Quinta-feira"; break;
 case 4: dia = "Sexta-feira"; break;
 case 5: dia = "Jum'at"; break;
 case 6: dia = "Sabtu"; break;
}
switch(mes) {
 case 0: mes = "Janeiro"; break;
 case 1: mes = "Fevereiro"; break;
 case 2: mes = "Marco"; break;
 case 3: mes = "Abril"; break;
 case 4: mes = "Maio"; break;
 case 5: mes = "Junho"; break;
 case 6: mes = "Julho"; break;
 case 7: mes = "Agosto"; break;
 case 8: mes = "Setembro"; break;
 case 9: mes = "Outubro"; break;
 case 10: mes = "Novembro"; break;
 case 11: mes = "Dezembro"; break;
}
var tampilTanggal = "ENCONTRO: " + dia + ", " + encontro + " " + mes + " " + ano;
var tampilWaktu = "hora: " + hora + ":" + minuto + ":" + segundo;
conn.sendMessage(id, info.info(id, BotName, corohelp, tampilTanggal, tampilWaktu, instagramlu, whatsapplu, kapanbotaktif, grupch1, grupch2) ,MessageType.text);
}
else if (text == '#gacha'){
conn.sendMessage(id, 'envie #gacha girl/boy\n\nExemplo: #gacha girl' ,MessageType.text);
}
   if (messageType == 'imageMessage')
   {
      let caption = imageMessage.caption.toLocaleLowerCase()
      const buffer = await conn.downloadMediaMessage(m) // to decrypt & use as a buffer
      if (caption == '#sticker')
      {
         const stiker = await conn.downloadAndSaveMediaMessage(m) // to decrypt & save to file

         const
         {
            exec
         } = require("child_process");
         exec('cwebp -q 50 ' + stiker + ' -o temp/' + hora + '.webp', (error, stdout, stderr) =>
         {
            let stik = fs.readFileSync('temp/' + hora + '.webp')
            conn.sendMessage(id, stik, MessageType.sticker)
         });
      }
   }

   if (messageType === MessageType.text)
   {
      let is = m.message.conversation.toLocaleLowerCase()

      if (is == '#pantun')
      {

         fetch('https://raw.githubusercontent.com/pajaar/grabbed-results/master/pajaar-2020-pantun-pakboy.txt')
            .then(res => res.text())
            .then(body =>
            {
               let tod = body.split("\n");
               let pjr = tod[Math.floor(Math.random() * tod.length)];
               let pantun = pjr.replace(/pjrx-line/g, "\n");
               conn.sendMessage(id, pantun, MessageType.text)
            });
      }

   }
/*   if (text.includes("#yt"))
   {
      const url = text.replace(/#yt/, "");
      const exec = require('child_process').exec;

      var videoid = url.match(/(?:https?:\/{2})?(?:w{3}\.)?youtu(?:be)?\.(?:com|be)(?:\/watch\?v=|\/)([^\s&]+)/);

      const ytdl = require("ytdl-core")
      if (videoid != null)
      {
         console.log("video id = ", videoid[1]);
      }
      else
      {
         conn.sendMessage(id, "gavalid", MessageType.text)
      }
      ytdl.getInfo(videoid[1]).then(info =>
      {
         if (info.length_seconds > 1000)
         {
            conn.sendMessage(id, " videonya kepanjangan", MessageType.text)
         }
         else
         {

            console.log(info.length_seconds)

            function os_func()
            {
               this.execCommand = function (cmd)
               {
                  return new Promise((resolve, reject) =>
                  {
                     exec(cmd, (error, stdout, stderr) =>
                     {
                        if (error)
                        {
                           reject(error);
                           return;
                        }
                        resolve(stdout)
                     });
                  })
               }
            }
            var os = new os_func();

            os.execCommand('ytdl ' + url + ' -q highest -o mp4/' + videoid[1] + '.mp4').then(res =>
            {
		const buffer = fs.readFileSync("mp4/"+ videoid[1] +".mp4")
               conn.sendMessage(id, buffer, MessageType.video)
            }).catch(err =>
            {
               console.log("os >>>", err);
            })

         }
      });

   }*/


   /*if (text.includes("#nulis"))
   {

      const
      {
         spawn
      } = require("child_process");
      console.log("writing...")
      const teks = text.replace(/#nulis/, "")
      const split = teks.replace(/(\S+\s*){1,10}/g, "$&\n")
      const fixedHeight = split.split("\n").slice(0, 25).join("\\n")
      console.log(split)
      spawn("convert", [
            "./assets/paper.jpg",
            "-font",
            "Indie-Flower",
            "-size",
            "700x960",
            "-pointsize",
            "18",
            "-interline-spacing",
            "3",
            "-annotate",
            "+170+222",
            fixedHeight,
            "./assets/result.jpg"
         ])
         .on("error", () => console.log("error"))
         .on("exit", () =>
         {
            const buffer = fs.readFileSync("assets/result.jpg") // can send mp3, mp4, & ogg -- but for mp3 files the mimetype must be set to ogg

            conn.sendMessage(id, buffer, MessageType.image)
            console.log("done")
         })
   }


   if (text.includes("#quotes"))
   {
      var url = 'https://jagokata.com/kata-bijak/acak.html'
      axios.get(url)
         .then((result) =>
         {
            let $ = cheerio.load(result.data);
            var author = $('a[class="auteurfbnaam"]').contents().first().text();
            var kata = $('q[class="fbquote"]').contents().first().text();

            conn.sendMessage(
               id,
               `
     _${kata}_
        
    
	*~${author}*
         `, MessageType.text
            );

         });
   }*/

   if (text.includes("#gacha girl"))
   {
    var items = ["ullzang girl", "cewe cantik", "hijab cantik", "korean girl"];
    var cewe = items[Math.floor(Math.random() * items.length)];
    var url = "https://api.fdci.se/rep.php?gambar=" + cewe;
    
    axios.get(url)
      .then((result) => {
        var b = JSON.parse(JSON.stringify(result.data));
        var cewek =  b[Math.floor(Math.random() * b.length)];
        imageToBase64(cewek) // Path to the image
        .then(
            (response) => {
	var buf = Buffer.from(response, 'base64'); // Ta-da	
              conn.sendMessage(
            id,
              buf,MessageType.image)
       
            }
        )
        .catch(
            (error) => {
                console.log(error); // Logs an error if there was one
            }
        )
    
    });
    }

   if (text.includes("#gacha boy"))
   {
    var items = ["cowo ganteng", "cogan", "korean boy", "chinese boy", "japan boy"];
    var cewe = items[Math.floor(Math.random() * items.length)];
    var url = "https://api.fdci.se/rep.php?gambar=" + cewe;
    
    axios.get(url)
      .then((result) => {
        var b = JSON.parse(JSON.stringify(result.data));
        var cewek =  b[Math.floor(Math.random() * b.length)];
        imageToBase64(cewek) // Path to the image
        .then(
            (response) => {
  var buf = Buffer.from(response, 'base64'); // Ta-da 
              conn.sendMessage(
            id,
              buf,MessageType.image)
       
            }
        )
        .catch(
            (error) => {
                console.log(error); // Logs an error if there was one
            }
        )
    
    });
    }

if (text.includes("#randomanime"))
   {
    var items = ["anime girl", "anime cantik", "anime", "anime aesthetic"];
    var cewe = items[Math.floor(Math.random() * items.length)];
    var url = "https://api.fdci.se/rep.php?gambar=" + cewe;
    
    axios.get(url)
      .then((result) => {
        var b = JSON.parse(JSON.stringify(result.data));
        var cewek =  b[Math.floor(Math.random() * b.length)];
        imageToBase64(cewek) // Path to the image
        .then(
            (response) => {
	var buf = Buffer.from(response, 'base64'); // Ta-da	
              conn.sendMessage(
            id,
              buf,MessageType.image)
       
            }
        )
        .catch(
            (error) => {
                console.log(error); // Logs an error if there was one
            }
        )
    
    });
    }

if (text.includes("#scdl")){
const fs = require("fs");
const scdl = require("./lib/scdl");

scdl.setClientID("iZIs9mchVcX5lhVRyQGGAYlNPVldzAoX");

scdl("https://m.soundcloud.com/abdul-muttaqin-701361735/lucid-dreams-gustixa-ft-vict-molina")
    .pipe(fs.createWriteStream("mp3/song.mp3"));
}



 else if (text.includes("#tts")) {
  var teks = text.split("#ttsid ")[1];
  var path = require('path');
  var text1 = teks.slice(6);
  text1 = suara;
  var suara = text.replace(/#ttsid/g, text1);
  var filepath = 'mp3/bacot.wav';
  
  
/*
 * save audio file
 */

gtts.save(filepath, suara, function() {
  console.log(`${filepath} MP3 SALVO!`)
});
await new Promise(resolve => setTimeout(resolve, 500));

	if(suara.length > 200){ // check longness of text, because otherways google translate will give me a empty file
  msg.reply("TEXTO MUITO GRANDE")
}else{

const buffer = fs.readFileSync(filepath)
	conn.sendMessage(id , buffer , MessageType.audio);

};


}






   // end of file


})
